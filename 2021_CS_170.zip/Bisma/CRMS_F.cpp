#include<iostream>
#include<conio.h>
#include<stdlib.h>

using namespace std;
// global variable declaration

   char status;
   int id=0;
   string password;    
void header (){
cout<<"***********************************************************"<<endl;
cout<<"*                   Welcome to our company                *"<<endl;
cout<<"***********************************************************"<<endl;
}
// end of header function

void header1 (){
         cout<<"////////////////////////////////////////////////////////////"<<endl;
         cout<<"--          Car Rental Management System (CRMS)           --"<<endl;
         cout<<"////////////////////////////////////////////////////////////"<<endl;
}
// end of 2nd header function

void system_cls()
{
      cout<<"Press any key to continue...."<<endl;
      getch();
      system ("CLS");
}
// end of system_cls function

char status_menu()
{
    header();
   cout<<"Select your Status:  >"<<endl;
   cout<<"a.... Admin"<<endl;
   cout<<"b.... Driver"<<endl;
   cout<<"c.... Customer"<<endl;
   cout<<"d.... Exit"<<endl;
   cout<<"Choose your option: ";  
   cin >> status;
   system_cls();
   return status;
  }
  // end of status_menu
  
  char login_portal()
  {
      if (status == 'a' || status == 'b' || status == 'c')
    {
      header1();
     cout <<"               Login Portal                "<<endl;
     cout <<"Enter User ID--------";
     cin >> id;
     cout <<"Enter Password--------";
     cin >> password;
     system_cls();
    }
  }
   // end of login portal function

   char admin_menu(char option)
      {
         header();
         cout<<"Main Menu   "<<endl;
         cout<<"Select one of the following options number . . ."<<endl;
         cout<<"1.  Display Car's model"<<endl;
         cout<<"2.  Add new customers"<<endl;
         cout<<"3.  Remove customer"<<endl;
         cout<<"4.  Change rent of cars"<<endl;  
         cout<<"5.  Add new driver"<<endl;
         cout<<"6.  Remove driver"<<endl;
         cout<<"7.  View all customers record"<<endl;  
         cout<<"8.  View all drivers record"<<endl;
         cout<<"9.  logout"<<endl;
         cout<<"Choose your option: ";  
         cin >> option;
         system_cls();
         return option;
       }
         // end of admin's menu
       
     char cust_menu(char option) 
       {
         header();
         cout<<"Main Menu   "<<endl;
         cout<<"Select one of the following options number . . ."<<endl;
         cout<<"1.  Display Car under budget"<<endl;
         cout<<"2.  Display rent for all cars"<<endl;
         cout<<"3.  Display cars from higher to lower rent"<<endl;
         cout<<"4.  Display car with and without driver"<<endl;  
         cout<<"5.  Invoice"<<endl;
          cout<<"6.  Logout"<<endl;
         cout<<"Choose your option: ";  
         cin >> option;
         system_cls();
         return option;
        }

       // end of customer's menu  
      
       // start of driver's menu 
     char driver_menu(char option)
         {
               header();
               cout<<"Main Menu   "<<endl;
               cout<<"Select one of the following options number . . ."<<endl;
               cout<<"1.  Driver's detail"<<endl;
               cout<<"2.  Display  my Car's model"<<endl;
               cout<<"3.  Display car status"<<endl;
               cout<<"4.  Logout"<<endl; 
               cout <<"Enter your option: ";
               cin >> option;
               system_cls();
               return option;
         }

         // end of driver's menu
    void wrong_password()
      {
         cout <<"Your Password is incorrect. Try again....."<<endl;
      }

        // end of menu function

        void cust_display (string cust_name, int cust_id, string cust_p)
        {
          cout <<"All customer's record:"<<endl;
          if (cust_id > 0)
          {
             cout << "Customer_name: "<< cust_name <<endl;
             cout << "Customer_ID: "<< cust_id <<endl;
             cout << "Password: "<< cust_p << endl;
             cout<<"                     "<<endl;
          }
       }
       // end of display customers function

    void driver_display (string driver_name, int driver_id, string driver_p)
        {
          cout <<"All driver's record:"<<endl;
          if (driver_id > 0)
          {
             cout << "Driver_name: "<< driver_name <<endl;
             cout << "Driver_ID: "<< driver_id <<endl;
             cout << "Password: "<< driver_p << endl;
             cout<<"                     "<<endl;
          }
       }
    // end of display driver function
    
    void models()
    {
            header1();
            cout<<"All car's model  >"<<endl;
            cout<<"A: Alto Suzuki 2016 model "<<endl;
            cout<<"B: Honda city 2015 model"<<endl;
            cout<<"C: Toyota Fortuner 2018 model"<<endl;
            cout<<"D: Wagon R 2021 model"<<endl;
            system_cls();
    }
    // end of display model function
     void car_driver()
    {
          header1();
          cout << "Cars Avaiable with driver are:"<< endl;
          cout <<"                                 "<<endl;
          cout<< "Honda city 2015 model"<<endl;
          cout<<"Rent for toyota fortuner"<<endl;
          cout <<"                                 "<<endl;
          cout << "Cars Avaiable without driver are:"<< endl;
          cout <<"                                 "<<endl;
          cout<< "Alto Suzuki 2016 model"<<endl;
          cout<<"Wagon R 2021 model"<<endl;
    }
// evd of car_driver function

   void invoice(string c_name, int c_id, string car_name, int day, int rent, int Advance, int rental_amount, int total_amount)
   {
          header1();
          cout << "Invoice of a customer: "<< endl;
          cout <<"                                 "<<endl;
          cout<<"Enter name: ";
          cin >> c_name;
          cout << "Enter ID: ";
          cin >> c_id;
          cout << "Enter Car model without space: ";
          cin >> car_name;
          cout<< "Enter number of days: ";
          cin >> day;
          cout << "Rent per day: ";
          cin >> rent;
           rental_amount = day * rent;
          cout <<"Enter Advance (equal to per day): ";
          cin >> Advance;
           total_amount = rental_amount - Advance;
           cout << "YOU HAVE TO PAY AFTER ADVANCE IS: "<<total_amount<< endl;
 }
   // end of invoice function

void Budget(int budget)
{
          header1();
          cout <<"Enter your budget: ";
          cin >> budget;
          if (budget > 1000 && budget <= 4000)
          cout <<"A: Alto suzuki 2016 model"<<endl;
          else if (budget > 4000 && budget <= 6000)
          {
          cout<< "A: Alto suzuki 2016 model"<<endl;
          cout<< "B: Honda city 2015 model"<<endl;
          cout<< "C: Wagon R 2021 model"<<endl;
          }
          else
          {
          cout<< "A: Alto suzuki 2016 model"<<endl;
          cout<< "B: Honda city 2015 model"<<endl;
          cout<< "C: Wagon R 2021 model"<<endl;
          cout<<"D: toyota fortuner"<<endl;
          }
          system_cls();
}
// end of budget function;
void car(int id, string driver1_name,  int driver1_id, string car1, string driver2_name, int driver2_id, string car2 )
{
          if (id == 734)
            cout << driver1_name <<"\t"<< driver1_id <<"\t" << car1<<endl;
           else if (id == 765)
           cout << driver2_name <<"\t"<< driver2_id <<"\t" << car2<<endl;
}
// end of car function
void available_car(string car1, string car2)
{
              if ((car1 == "Toyotafortuner" || car1 == "Hondacity") || ( car2 == "Toyotafortuner" || car2 == "Hondacity"))
              cout << "Your car is Available...."<<endl;
            else
              cout <<"Car is not available....."<<endl;
}
// end of available car