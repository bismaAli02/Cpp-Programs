#include<iostream>
using namespace std;

char menu()
{
    char option;
    cout<<"----------Calculator-------------"<<endl;
    cout<<"press 1 for add------"<<endl;
    cout<<"press 2 for subatract------"<<endl;
    cout<<"press 3 for multiply------"<<endl;
    cout<<"press 4 for divide------"<<endl;
    cout<<"Choose your option: ";
    cin >> option;
    return option;
}
main()
{
    char opt;
    float x=0, y=0, sum=0, mul=0, div=0, subtract=0;
  while (true)
  { 
    cout<<"Enter 1st number: ";
    cin>> x;
    cout<<"Enter 2nd number: ";
    cin>>y;
    char option = menu();
    if (option == '1')
    {
      sum = x+y;
      cout <<"Answer is: "<< sum<<endl;
    }
    else if(option == '2')
    {
        subtract = x-y;
        cout<<"Answer is: " <<subtract <<endl;
    }
    else if(option == '3')
    {
        mul = x*y;
        cout<<"Answer is: "<< mul<<endl;
    }
    else if(option == '4')
    {
        div = x/y;
        cout <<"Answer is: "<< div <<endl;
    }
    cout <<"You want to perform more operation press y for yes and n for no: ";
    cin>> opt;
    if(opt == 'n')
    break;
  }
}

